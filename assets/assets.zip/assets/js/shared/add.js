$(function(){

	
$(document).on('click','#click_create_project', function(){

$("#create_project").modal();

});	

$(document).on('click','#expand', function(){
	


});	


$(document).on('click','button#save_project', function(){
	
    $("#save_project").attr("disabled","disabled");
	var project_name = $("#project_name").val();
	var priority = $("#priority").val();
	var category = $("#category").val();
	var asssign = $("#assign").val();
	var start_date = $("#start_date").val();	
	var end_date = $("#end_date").val(); 
	var through = $("#through").val();
	var src = $("#source").val();
	var comment = $("#comments").val();
	var start = $("#start").val();
	 
	 
	if(project_name == "" || priority == 0 || category == 0 || asssign == 0 || start_date == 0 || end_date == 0 || through == 0 || src == 0){
		alert("Enter Required Details First");
		$("#save_project").removeAttr("disabled");
	}

	else{
	  if(comment == ""){
	  alert("NOTE : You are about to save without writing any remarks/comments");
	  }
	$.ajax({
	    type: "POST",
		url: "../../modules/save_project.php",
		data: {
		project_name: project_name,
		priority: priority,
		category: category,
		asssign: asssign,
		start_date: start_date,
		end_date: end_date,
		through: through,
		src: src,
		comment: comment,
		start: start
		},
		cache: false,
		success: function(data){
		  alert(data);
		  $("#project_name").val("");
		  $('#priority').prop('selectedIndex',0);
          $('#category').prop('selectedIndex',0);		  
		  $('#assign').prop('selectedIndex',0);
		  $("#save_project").removeAttr("disabled");
		  $("#create_project").modal('hide');
		  
		},
		error: function(xhr, status, error){
		  console.error(xhr);
		}
		});
	
	}
	

});



//$('#project_name_or').on('keypress', function (event) {
  //  var regex = new RegExp("[a-zA-Z0-9]+$");
   // var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
    //if (!regex.test(key)) {
      // event.preventDefault();
      // return false;
    //}
//});

















});